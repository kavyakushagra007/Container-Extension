// ── State ──
let allItems = [];
let currentFilter = "all";
let searchQuery = "";
let editingItemId = null;

// ── DOM Elements ──
const itemsContainer = document.getElementById("items-container");
const emptyState = document.getElementById("empty-state");
const searchInput = document.getElementById("search-input");
const filterBtns = document.querySelectorAll(".filter-btn");
const btnAdd = document.getElementById("btn-add");
const btnPaste = document.getElementById("btn-paste");
const btnDashboard = document.getElementById("btn-dashboard");
const btnMenu = document.getElementById("btn-menu");
const dropdownMenu = document.getElementById("dropdown-menu");
const countBar = document.getElementById("count-bar");
const itemCount = document.getElementById("item-count");

// Add modal
const addModal = document.getElementById("add-modal");
const addContent = document.getElementById("add-content");
const addTags = document.getElementById("add-tags");
const modalCancel = document.getElementById("modal-cancel");
const modalSave = document.getElementById("modal-save");

// Edit modal
const editModal = document.getElementById("edit-modal");
const editContent = document.getElementById("edit-content");
const editTags = document.getElementById("edit-tags");
const editCancel = document.getElementById("edit-cancel");
const editSave = document.getElementById("edit-save");

const toast = document.getElementById("toast");
const importFile = document.getElementById("import-file");

// ── Init ──
document.addEventListener("DOMContentLoaded", loadItems);

async function loadItems() {
  chrome.runtime.sendMessage({ action: "getItems" }, (items) => {
    allItems = items || [];
    renderItems();
  });
}

// ── Render ──
function renderItems() {
  const filtered = allItems.filter((item) => {
    if (currentFilter === "favorite" && !item.favorite) return false;
    if (currentFilter !== "all" && currentFilter !== "favorite" && item.type !== currentFilter)
      return false;

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchContent = item.content.toLowerCase().includes(q);
      const matchTags = item.tags?.some((t) => t.toLowerCase().includes(q));
      const matchSource = item.sourceTitle?.toLowerCase().includes(q);
      if (!matchContent && !matchTags && !matchSource) return false;
    }

    return true;
  });

  // Update item count
  if (allItems.length > 0) {
    countBar.classList.remove("hidden");
    if (searchQuery || currentFilter !== "all") {
      itemCount.textContent = `${filtered.length} of ${allItems.length} items`;
    } else {
      itemCount.textContent = `${allItems.length} item${allItems.length !== 1 ? "s" : ""} saved`;
    }
  } else {
    countBar.classList.add("hidden");
  }

  if (filtered.length === 0) {
    itemsContainer.classList.add("hidden");
    emptyState.classList.remove("hidden");
    return;
  }

  itemsContainer.classList.remove("hidden");
  emptyState.classList.add("hidden");

  itemsContainer.innerHTML = filtered.map((item) => createItemHTML(item)).join("");

  // Attach event listeners
  itemsContainer.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", handleItemAction);
  });

  // Expand on click
  itemsContainer.querySelectorAll(".item-content").forEach((el) => {
    el.addEventListener("click", () => el.classList.toggle("expanded"));
  });

  // Clickable tags
  itemsContainer.querySelectorAll(".tag").forEach((tagEl) => {
    tagEl.addEventListener("click", (e) => {
      e.stopPropagation();
      const tag = e.currentTarget.dataset.tag;
      if (tag) {
        searchInput.value = tag;
        searchQuery = tag;
        renderItems();
      }
    });
  });
}

function createItemHTML(item) {
  const date = new Date(item.createdAt);
  const timeAgo = getTimeAgo(date);
  const badgeClass = item.type === "link" ? "badge-link" : "badge-text";
  const typeLabel = item.type === "link" ? "Link" : "Text";

  let contentHTML;
  if (item.type === "link") {
    const url = /^https?:\/\//i.test(item.content) ? item.content : `https://${item.content}`;
    contentHTML = `<a href="${escapeHTML(url)}" target="_blank" rel="noopener">${escapeHTML(item.content)}</a>`;
  } else {
    contentHTML = escapeHTML(item.content);
  }

  const tagsHTML =
    item.tags?.length > 0
      ? `<div class="item-tags">${item.tags.map((t) => `<span class="tag" data-tag="${escapeHTML(t)}">#${escapeHTML(t)}</span>`).join("")}</div>`
      : "";

  const sourceHTML = item.sourceTitle
    ? `<span class="item-source" title="${escapeHTML(item.sourceUrl)}">from ${escapeHTML(item.sourceTitle)}</span>`
    : "";

  return `
    <div class="item-card" data-id="${item.id}">
      <div class="item-top">
        <span class="item-type-badge ${badgeClass}">${typeLabel}</span>
        <div class="item-actions">
          <button class="item-action-btn ${item.favorite ? "favorite-active" : ""}" data-action="favorite" data-id="${item.id}" title="Favorite">
            <svg viewBox="0 0 24 24" fill="${item.favorite ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
          </button>
          <button class="item-action-btn edit-btn" data-action="edit" data-id="${item.id}" title="Edit">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          <button class="item-action-btn" data-action="copy" data-id="${item.id}" title="Copy">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
          </button>
          <button class="item-action-btn delete-btn" data-action="delete" data-id="${item.id}" title="Delete">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
          </button>
        </div>
      </div>
      <div class="item-content">${contentHTML}</div>
      ${tagsHTML}
      <div class="item-meta">
        <span>${timeAgo}</span>
        ${sourceHTML ? "·" : ""}
        ${sourceHTML}
      </div>
    </div>
  `;
}

// ── Item Actions ──
function handleItemAction(e) {
  const btn = e.currentTarget;
  const action = btn.dataset.action;
  const id = btn.dataset.id;

  if (action === "copy") {
    const item = allItems.find((i) => i.id === id);
    if (item) {
      navigator.clipboard.writeText(item.content);
      showToast("Copied to clipboard!");
      const originalHTML = btn.innerHTML;
      btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="color:var(--neon-green);"><polyline points="20 6 9 17 4 12"/></svg>`;
      setTimeout(() => (btn.innerHTML = originalHTML), 1200);
    }
  }

  if (action === "favorite") {
    const item = allItems.find((i) => i.id === id);
    if (item) {
      item.favorite = !item.favorite;
      chrome.runtime.sendMessage({ action: "updateItem", item }, () => {
        renderItems();
      });
    }
  }

  if (action === "edit") {
    const item = allItems.find((i) => i.id === id);
    if (item) {
      editingItemId = id;
      editContent.value = item.content;
      editTags.value = (item.tags || []).join(", ");
      editModal.classList.remove("hidden");
      editContent.focus();
    }
  }

  if (action === "delete") {
    chrome.runtime.sendMessage({ action: "deleteItem", id }, () => {
      allItems = allItems.filter((i) => i.id !== id);
      renderItems();
      showToast("Item deleted");
    });
  }
}

// ── Paste from Clipboard ──
btnPaste.addEventListener("click", async () => {
  try {
    const text = await navigator.clipboard.readText();
    if (!text || !text.trim()) {
      showToast("Clipboard is empty");
      return;
    }

    // Auto-detect if it's a URL
    const isUrl = /^https?:\/\//i.test(text.trim());

    const item = {
      id: Date.now().toString(36) + Math.random().toString(36).substr(2, 9),
      type: isUrl ? "link" : "text",
      content: text.trim(),
      sourceUrl: "",
      sourceTitle: "",
      createdAt: Date.now(),
      tags: [],
      favorite: false,
    };

    chrome.runtime.sendMessage({ action: "saveItem", item }, () => {
      allItems.unshift(item);
      renderItems();
      showToast(`${isUrl ? "Link" : "Text"} saved from clipboard!`);
    });
  } catch {
    showToast("Cannot read clipboard – allow permission");
  }
});

// ── Search ──
searchInput.addEventListener("input", (e) => {
  searchQuery = e.target.value;
  renderItems();
});

// ── Filters ──
filterBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    filterBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    currentFilter = btn.dataset.filter;
    renderItems();
  });
});

// ── Add Modal ──
btnAdd.addEventListener("click", () => {
  addModal.classList.remove("hidden");
  addContent.value = "";
  addTags.value = "";
  addContent.focus();
});

modalCancel.addEventListener("click", () => addModal.classList.add("hidden"));
addModal.querySelector(".modal-backdrop").addEventListener("click", () =>
  addModal.classList.add("hidden")
);

modalSave.addEventListener("click", () => {
  const content = addContent.value.trim();
  if (!content) {
    addContent.style.borderColor = "var(--red)";
    setTimeout(() => (addContent.style.borderColor = ""), 1000);
    return;
  }

  const tags = addTags.value
    .split(",")
    .map((t) => t.trim())
    .filter((t) => t);

  const isUrl = /^https?:\/\//i.test(content) || /^(www\.)/i.test(content);
  const type = isUrl ? "link" : "text";

  const item = {
    id: Date.now().toString(36) + Math.random().toString(36).substr(2, 9),
    type,
    content,
    sourceUrl: "",
    sourceTitle: "",
    createdAt: Date.now(),
    tags,
    favorite: false,
  };

  chrome.runtime.sendMessage({ action: "saveItem", item }, () => {
    allItems.unshift(item);
    renderItems();
    addModal.classList.add("hidden");
    showToast("Item saved!");
  });
});

// ── Edit Modal ──
editCancel.addEventListener("click", () => {
  editModal.classList.add("hidden");
  editingItemId = null;
});
editModal.querySelector(".modal-backdrop").addEventListener("click", () => {
  editModal.classList.add("hidden");
  editingItemId = null;
});

editSave.addEventListener("click", () => {
  const content = editContent.value.trim();
  if (!content) {
    editContent.style.borderColor = "var(--red)";
    setTimeout(() => (editContent.style.borderColor = ""), 1000);
    return;
  }

  const tags = editTags.value
    .split(",")
    .map((t) => t.trim())
    .filter((t) => t);

  const item = allItems.find((i) => i.id === editingItemId);
  if (item) {
    item.content = content;
    item.tags = tags;
    chrome.runtime.sendMessage({ action: "updateItem", item }, () => {
      renderItems();
      editModal.classList.add("hidden");
      editingItemId = null;
      showToast("Item updated!");
    });
  }
});

// ── Dropdown Menu ──
btnMenu.addEventListener("click", (e) => {
  e.stopPropagation();
  dropdownMenu.classList.toggle("hidden");
});

document.addEventListener("click", () => dropdownMenu.classList.add("hidden"));

function openDashboard() {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
}

if (btnDashboard) {
  btnDashboard.addEventListener("click", openDashboard);
}

const menuDashboard = document.getElementById("menu-dashboard");
if (menuDashboard) {
  menuDashboard.addEventListener("click", () => {
    dropdownMenu.classList.add("hidden");
    openDashboard();
  });
}

// Export
document.getElementById("menu-export").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "exportItems" }, (items) => {
    const blob = new Blob([JSON.stringify(items, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `saveit-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast("Exported successfully!");
  });
});

// Import
document.getElementById("menu-import").addEventListener("click", () => {
  importFile.click();
});

importFile.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    try {
      const items = JSON.parse(event.target.result);
      if (!Array.isArray(items)) throw new Error("Invalid format");

      chrome.runtime.sendMessage({ action: "importItems", items }, () => {
        loadItems();
        showToast(`Imported ${items.length} items!`);
      });
    } catch {
      showToast("Invalid file format");
    }
  };
  reader.readAsText(file);
  importFile.value = "";
});

// Clear All
document.getElementById("menu-clear").addEventListener("click", () => {
  if (confirm("Delete ALL saved items? This cannot be undone.")) {
    chrome.runtime.sendMessage({ action: "clearAll" }, () => {
      allItems = [];
      renderItems();
      showToast("All items cleared");
    });
  }
});

// ── Helpers ──
function escapeHTML(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function getTimeAgo(date) {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months}mo ago`;
  return `${Math.floor(months / 12)}y ago`;
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 2000);
}
